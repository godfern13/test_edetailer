
$(document).ready(function() {
        $.get('slide.xml',function(data){
			
			var strtXpt = $(data).find('start_x_point').text();
			var strtYpt = $(data).find('start_y_point').text();
			var plotFlag = true;//enable start points
			var new_x;
			var new_y;
				
			$(data).find('points').each(function(){
				var x = $(this).find('x').text();
				var y =	$(this).find('y').text();
				
				canvas = document.getElementById('imageView');
				context = canvas.getContext('2d');
				context.beginPath();
				
				if(plotFlag == true){
					//Moves to x-axis and y-axis with strtXpt and strtYpt values
					context.moveTo(strtXpt,strtYpt);
					plotFlag = false;//diable start points					 
				}
				else{
					context.moveTo(new_x,new_y);//changes start points to new x-axis and y-axis with new_x and new_y values
				}
				//Drawing end point
				context.lineTo(parseInt(x),parseInt(y));
				new_x = parseInt(x);
				new_y = parseInt(y);
				//Draws
				context.stroke();
			});
	    });
	});
