<?php

	$x_strt_pt 	= $_POST['sXpt'];
	$y_strt_pt 	= $_POST['sYpt'];
	$x_end_pt 	= $_POST['eXpt'];
	$y_end_pt 	= $_POST['eYpt'];
	$x_all_pt 	= $_POST['lXpt'];
	$y_all_pt 	= $_POST['lYpt'];
	
	//echo $x_strt_pt ;
	$xml = new DOMDocument("1.0");
 
	$root = $xml->createElement("data");
	$xml->appendChild($root);
	 
	$start_point   = $xml->createElement("start_point");
	
	$start_x_point   = $xml->createElement("start_x_point");
	$sx_pt = $xml->createTextNode($x_strt_pt);
	$start_x_point->appendChild($sx_pt);	
	
	$start_y_point   = $xml->createElement("start_y_point");
	$sy_pt = $xml->createTextNode($y_strt_pt);
	$start_y_point->appendChild($sy_pt);	
	
	$start_point->appendChild($start_x_point);
	$start_point->appendChild($start_y_point);
	
	
	$end_point   = $xml->createElement("end_point");
		 
	$end_x_point   = $xml->createElement("end_x_point");
	$sx_pt = $xml->createTextNode($x_end_pt);
	$end_x_point->appendChild($sx_pt);
	
	$end_y_point   = $xml->createElement("end_y_point");
	$sy_pt = $xml->createTextNode($y_end_pt);
	$end_y_point->appendChild($sy_pt);
	
	$end_point->appendChild($end_x_point);
	$end_point->appendChild($end_y_point);
	
	
	$all_points   = $xml->createElement("all_points");
		 
	
	
	//$all_points->appendChild($points);
	$x_arr = explode(',',$x_all_pt);
	$y_arr = explode(',',$y_all_pt);
	$x_arr_size = count($x_arr);
	//print_r($x_arr);
	
	for($i=0;$i<$x_arr_size;$i++){
		
		
		$points   = $xml->createElement("points");
		$x_point   = $xml->createElement("x");
		$x_pt = $xml->createTextNode($x_arr[$i]);
		$x_point->appendChild($x_pt);
		
		$y_point   = $xml->createElement("y");
		$y_pt = $xml->createTextNode($y_arr[$i]);
		$y_point->appendChild($y_pt);
		
		$points->appendChild($x_point);
		$points->appendChild($y_point);

		$all_points->appendChild($points);
	}
		 
	$slide = $xml->createElement("slide");
	$slide->appendChild($start_point);
	$slide->appendChild($end_point);
	$slide->appendChild($all_points);
	
	 
	$root->appendChild($slide);
	 
	$xml->formatOutput = true;
	echo "<xmp>". $xml->saveXML() ."</xmp>";
	 
	$xml->save("slide.xml") or die("Error");
	
?>